<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');


$config['protocol'] = 'smtp';
$config['smtp_host'] = 'smtp.1and1.es';
$config['smtp_port'] = 587;
$config['smtp_crypto'] = 'tls';
$config['smtp_user'] = 'info@faycabsecurity.com';
$config['smtp_pass'] = 'Samia074769492@';
$config['mailtype'] = 'html';
$config['charset'] = 'utf-8';