<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$route['default_controller'] = 'something';
$route['404_override'] = 'Error_404/error_page';
$route['translate_uri_dashes'] = FALSE;

// default route
$route['dashboard'] = 'dashboard';
$route['administrator'] = 'administrator';

// profile
$route['admin/profile']                             = 'user/profile';
$route['admin/update-profile']                      = 'user/update_profile';
$route['admin/update-profile-picture']              = 'user/update_profile_picture';

// user
$route['admin/users']['get']                        = 'user/index';
$route['admin/user/create']['get']                  = 'user/create';
$route['admin/user/store']['post']                  = 'user/store';
$route['admin/user/edit/(:num)']['get']             = 'user/edit/$1';
$route['admin/user/update/(:num)']['post']          = 'user/update/$1';
$route['admin/user/delete/(:num)']['get']           = 'user/delete/$1';
$route['admin/user/change-status/(:num)']['get']    = 'user/status/$1';

// Settings
$route['admin/settings/software-settings']['get']               = 'settings/software_settings';
$route['admin/settings/update-software-settings']['post']       = 'settings/update_software_settings';
$route['admin/settings/social-settings']['get']                 = 'settings/social_settings';
$route['admin/settings/update-social-settings']['post']         = 'settings/update_social_settings';
$route['admin/settings/administrator-login-settings']['get']    = 'settings/admin_login';
$route['admin/settings/administrator-login-update']['post']     = 'settings/update_admin_login';

// home-page/section-one
$route['admin/home-page/section-one']['get'] = 'homepage/section_one';
$route['admin/home-page/update-section-one']['post'] = 'homepage/update_section_one';
$route['admin/home-page/section-two']['get'] = 'homepage/section_two';
$route['admin/home-page/section-two-create']['get'] = 'homepage/section_two_create';
$route['admin/home-page/section-two-store']['post'] = 'homepage/section_two_store';
$route['admin/home-page/section-two-edit/(:num)']['get'] = 'homepage/section_two_edit/$1';
$route['admin/home-page/section-two-update/(:num)']['post'] = 'homepage/section_two_update/$1';
$route['admin/home-page/section-two-delete/(:num)']['get'] = 'homepage/section_two_delete/$1';
$route['admin/home-page/section-three']['get'] = 'homepage/section_three';
$route['admin/home-page/update-section-three']['post'] = 'homepage/update_section_three';
$route['admin/home-page/section-four']['get'] = 'homepage/section_four';
$route['admin/home-page/update-section-four']['post'] = 'homepage/update_section_four';
$route['admin/home-page/section-four-create']['get'] = 'homepage/section_four_create';
$route['admin/home-page/section-four-store']['post'] = 'homepage/section_four_store';
$route['admin/home-page/section-four-edit/(:num)']['get'] = 'homepage/section_four_edit/$1';
$route['admin/home-page/section-four-update/(:num)']['post'] = 'homepage/section_four_update/$1';
$route['admin/home-page/section-four-delete/(:num)']['get'] = 'homepage/section_four_delete/$1';
$route['admin/home-page/section-five']['get'] = 'homepage/section_five';
$route['admin/home-page/update-section-five']['post'] = 'homepage/update_section_five';
$route['admin/home-page/section-five-create']['get'] = 'homepage/section_five_create';
$route['admin/home-page/section-five-store']['post'] = 'homepage/section_five_store';
$route['admin/home-page/section-five-edit/(:num)']['get'] = 'homepage/section_five_edit/$1';
$route['admin/home-page/section-five-update/(:num)']['post'] = 'homepage/section_five_update/$1';
$route['admin/home-page/section-five-delete/(:num)']['get'] = 'homepage/section_five_delete/$1';
$route['admin/home-page/section-six']['get'] = 'homepage/section_six';
$route['admin/home-page/update-section-six']['post'] = 'homepage/update_section_six';
$route['admin/home-page/section-seven']['get'] = 'homepage/section_seven';
$route['admin/home-page/update-section-seven']['post'] = 'homepage/update_section_seven';
$route['admin/home-page/section-eight']['get'] = 'homepage/section_eight';
$route['admin/home-page/update-section-eight']['post'] = 'homepage/update_section_eight';
$route['admin/home-page/section-nine']['get'] = 'homepage/section_nine';
$route['admin/home-page/update-section-nine']['post'] = 'homepage/update_section_nine';

$route['admin/home-page/section-ten']['get'] = 'homepage/section_ten';
$route['admin/home-page/update-section-ten']['post'] = 'homepage/update_section_ten';

$route['admin/home-page/section-ten/create']['get'] = 'homepage/section_ten_create';
$route['admin/home-page/section-ten/store']['post'] = 'homepage/section_ten_store';
$route['admin/home-page/section-ten/edit/(:num)']['get'] = 'homepage/section_ten_edit/$1';
$route['admin/home-page/section-ten/update/(:num)']['post'] = 'homepage/section_ten_update/$1';
$route['admin/home-page/section-ten/delete/(:num)']['get'] = 'homepage/section_ten_delete/$1';

$route['admin/home-page/section-eleven']['get'] = 'homepage/section_eleven';
$route['admin/home-page/update-section-eleven']['post'] = 'homepage/update_section_eleven';