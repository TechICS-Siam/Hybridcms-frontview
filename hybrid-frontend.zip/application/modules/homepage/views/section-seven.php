<ol class="breadcrumb df-breadcrumbs mg-b-10">
    <li class="breadcrumb-item">
        <a href="<?= base_url() ?>dashboard">Dashboard</a>
    </li>
    <li class="breadcrumb-item active" aria-current="page">Section Seven Configuration</li>
</ol>

<h1><span class="text-primary">Section Seven Configuration</span></h1>

<div class="row">
    <div class="col-md-12">
        <?php
        $success = $this->session->flashdata('success');
        $warning = $this->session->flashdata('warning');
        if (isset($success)) {?>
            <div class="alert session_alert alert-outline alert-success" role="alert">
                <strong>Well Done!</strong>  <?php echo $success; ?>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
        <?php } elseif (isset($warning)) { ?>
            <div class="alert session_alert alert-outline alert-danger" role="alert">
                <strong>Warning!</strong>  <?php echo $warning; ?>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span class="text-danger" aria-hidden="true">×</span>
                </button>
            </div>
        <?php } ?>
        <div data-label="Section Seven Configuration" class="df-example demo-table" >
            <form action="<?= site_url('admin/home-page/update-section-seven') ?>" method="post" enctype="multipart/form-data" id="user_form">
                <div class="row">
                    <!-- title -->
                    <div class="col-md-6 form-group">
                        <label for="title">Title <span class="text-danger">*</span></label>
                        <input type="text" name="title" id="title" class="form-control" placeholder="Enter Title One" required value="<?= $model->title ?>">
                    </div>

                    <!-- title_two -->
                    <div class="col-md-6 form-group">
                        <label for="title_two">Title Two <span class="text-danger">*</span></label>
                        <input type="text" name="title_two" id="title_two" class="form-control" placeholder="Enter Title Two" required value="<?= $model->title_two ?>">
                    </div>

                    <!-- description -->
                    <div class="col-md-12 form-group">
                        <label for="description">Description <span class="text-dager">*</span></label>
                        <textarea name="description" id="description" class="form-control" cols="30" rows="2"><?= $model->description ?></textarea>
                    </div>

                    <!-- button_one_text -->
                    <div class="col-md-4 form-group">
                        <label for="button_one_text">Button One Text <span class="text-danger">*</span></label>
                        <input type="text" name="button_one_text" id="button_one_text" class="form-control" required value="<?= $model->button_one_text?>" autocomplete="off" placeholder="Enter Button One Text">
                    </div>

                    <!-- button_one_url -->
                    <div class="col-md-4 form-group">
                        <label for="button_one_url">Button One URL </label>
                        <input type="text" name="button_one_url" id="button_one_url" class="form-control" value="<?= $model->button_one_url ?>" autocomplete="off" placeholder="Enter Button One URL">
                    </div>

                    <!-- button_one_open -->
                    <div class="col-md-4 form-group">
                        <label for="button_one_open">Do You Want To Open This Link On A New Tab? <span class="text-danger">*</span></label>
                        <select name="button_one_open" id="button_one_open" class="form-control select" >
                            <option <?= $model->button_one_open == 1 ? 'selected' : '' ?> value="1">Yes</option>
                            <option <?= $model->button_one_open == 0 ? 'selected' : '' ?> value="0">No</option>
                        </select>                
                    </div>

                    <!-- button_two_text -->
                    <div class="col-md-4 form-group">
                        <label for="button_two_text">Button Two Text <span class="text-danger">*</span></label>
                        <input type="text" name="button_two_text" id="button_two_text" class="form-control" required value="<?= $model->button_two_text ?>" autocomplete="off" placeholder="Enter Button Two Text">
                    </div>

                    <!-- button_two_url -->
                    <div class="col-md-4 form-group">
                        <label for="button_two_url">Button Two URL </label>
                        <input type="text" name="button_two_url" id="button_two_url" class="form-control" value="<?= $model->button_two_url ?>" autocomplete="off" placeholder="Enter Button Two URL">
                    </div>

                    <!-- button_two_open -->
                    <div class="col-md-4 form-group">
                        <label for="button_two_open">Do You Want To Open This Link On A New Tab? <span class="text-danger">*</span></label>
                        <select name="button_two_open" id="button_two_open" class="form-control select" >
                            <option <?= $model->button_two_open == 1 ? 'selected' : '' ?> value="1">Yes</option>
                            <option <?= $model->button_two_open == 0 ? 'selected' : '' ?> value="0">No</option>
                        </select>                
                    </div>

                    <!-- button_three_text -->
                    <div class="col-md-4 form-group">
                        <label for="button_three_text">Button Three Text <span class="text-danger">*</span></label>
                        <input type="text" name="button_three_text" id="button_three_text" class="form-control" required value="<?= $model->button_three_text ?>" autocomplete="off" placeholder="Enter Button Three Text">
                    </div>

                    <!-- button_three_url -->
                    <div class="col-md-4 form-group">
                        <label for="button_three_url">Button Three URL </label>
                        <input type="text" name="button_three_url" id="button_three_url" class="form-control" value="<?= $model->button_three_url ?>" autocomplete="off" placeholder="Enter Button Three URL">
                    </div>

                    <!-- button_three_open -->
                    <div class="col-md-4 form-group">
                        <label for="button_three_open">Do You Want To Open This Link On A New Tab? <span class="text-danger">*</span></label>
                        <select name="button_three_open" id="button_three_open" class="form-control select" >
                            <option <?= $model->button_three_open == 1 ? 'selected' : '' ?> value="1">Yes</option>
                            <option <?= $model->button_three_open == 0 ? 'selected' : '' ?> value="0">No</option>
                        </select>                
                    </div>
                    
                    <!-- button_four_text -->
                    <div class="col-md-4 form-group">
                        <label for="button_four_text">Button Four Text <span class="text-danger">*</span></label>
                        <input type="text" name="button_four_text" id="button_four_text" class="form-control" required value="<?= $model->button_four_text ?>" autocomplete="off" placeholder="Enter Button Four Text">
                    </div>

                    <!-- button_four_url -->
                    <div class="col-md-4 form-group">
                        <label for="button_four_url">Button Four URL </label>
                        <input type="text" name="button_four_url" id="button_four_url" class="form-control" value="<?= $model->button_four_url ?>" autocomplete="off" placeholder="Enter Button Four URL">
                    </div>

                    <!-- butthon_four_open -->
                    <div class="col-md-4 form-group">
                        <label for="butthon_four_open">Do You Want To Open This Link On A New Tab? <span class="text-danger">*</span></label>
                        <select name="butthon_four_open" id="butthon_four_open" class="form-control select" >
                            <option <?= $model->butthon_four_open == 1 ? 'selected' : '' ?> value="1">Yes</option>
                            <option <?= $model->butthon_four_open == 0 ? 'selected' : '' ?> value="0">No</option>
                        </select>                
                    </div>
                    
                    <!-- button_five_text -->
                    <div class="col-md-4 form-group">
                        <label for="button_five_text">Button Five Text <span class="text-danger">*</span></label>
                        <input type="text" name="button_five_text" id="button_five_text" class="form-control" required value="<?= $model->button_five_text ?>" autocomplete="off" placeholder="Enter Button Five Text">
                    </div>

                    <!-- button_five_url -->
                    <div class="col-md-4 form-group">
                        <label for="button_five_url">Button Five URL </label>
                        <input type="text" name="button_five_url" id="button_five_url" class="form-control" value="<?= $model->button_five_url ?>" autocomplete="off" placeholder="Enter Button Five URL">
                    </div>

                    <!-- button_five_open -->
                    <div class="col-md-4 form-group">
                        <label for="button_five_open">Do You Want To Open This Link On A New Tab? <span class="text-danger">*</span></label>
                        <select name="button_five_open" id="button_five_open" class="form-control select" >
                            <option <?= $model->button_five_open == 1 ? 'selected' : '' ?> value="1">Yes</option>
                            <option <?= $model->button_five_open == 0 ? 'selected' : '' ?> value="0">No</option>
                        </select>                
                    </div>
                    
                    <!-- button_six_text -->
                    <div class="col-md-4 form-group">
                        <label for="button_six_text">Button Six Text <span class="text-danger">*</span></label>
                        <input type="text" name="button_six_text" id="button_six_text" class="form-control" required value="<?= $model->button_six_text ?>" autocomplete="off" placeholder="Enter Button Six Text">
                    </div>

                    <!-- button_six_url -->
                    <div class="col-md-4 form-group">
                        <label for="button_six_url">Button Six URL </label>
                        <input type="text" name="button_six_url" id="button_six_url" class="form-control" value="<?= $model->button_six_url ?>" autocomplete="off" placeholder="Enter Button Six URL">
                    </div>

                    <!-- button_six_open -->
                    <div class="col-md-4 form-group">
                        <label for="button_six_open">Do You Want To Open This Link On A New Tab? <span class="text-danger">*</span></label>
                        <select name="button_six_open" id="button_six_open" class="form-control select" >
                            <option <?= $model->button_six_open == 1 ? 'selected' : '' ?> value="1">Yes</option>
                            <option <?= $model->button_six_open == 0 ? 'selected' : '' ?> value="0">No</option>
                        </select>                
                    </div>
                    
                    <!-- button_seven_text -->
                    <div class="col-md-4 form-group">
                        <label for="button_seven_text">Button Seven Text <span class="text-danger">*</span></label>
                        <input type="text" name="button_seven_text" id="button_seven_text" class="form-control" required value="<?= $model->button_seven_text ?>" autocomplete="off" placeholder="Enter Button Seven Text">
                    </div>

                    <!-- button_seven_url -->
                    <div class="col-md-4 form-group">
                        <label for="button_seven_url">Button Seven URL </label>
                        <input type="text" name="button_seven_url" id="button_seven_url" class="form-control" value="<?= $model->button_seven_url ?>" autocomplete="off" placeholder="Enter Button Seven URL">
                    </div>

                    <!-- button_seven_open -->
                    <div class="col-md-4 form-group">
                        <label for="button_seven_open">Do You Want To Open This Link On A New Tab? <span class="text-danger">*</span></label>
                        <select name="button_seven_open" id="button_seven_open" class="form-control select" >
                            <option <?= $model->button_seven_open == 1 ? 'selected' : '' ?> value="1">Yes</option>
                            <option <?= $model->button_seven_open == 0 ? 'selected' : '' ?> value="0">No</option>
                        </select>                
                    </div>
                    
                    <!-- button_eight_text -->
                    <div class="col-md-4 form-group">
                        <label for="button_eight_text">Button Eight Text <span class="text-danger">*</span></label>
                        <input type="text" name="button_eight_text" id="button_eight_text" class="form-control" required value="<?= $model->button_eight_text ?>" autocomplete="off" placeholder="Enter Button Eight Text">
                    </div>

                    <!-- button_eight_url -->
                    <div class="col-md-4 form-group">
                        <label for="button_eight_url">Button Eight URL </label>
                        <input type="text" name="button_eight_url" id="button_eight_url" class="form-control" value="<?= $model->button_eight_url ?>" autocomplete="off" placeholder="Enter Button Eight URL">
                    </div>

                    <!-- button_eight_open -->
                    <div class="col-md-4 form-group">
                        <label for="button_eight_open">Do You Want To Open This Link On A New Tab? <span class="text-danger">*</span></label>
                        <select name="button_eight_open" id="button_eight_open" class="form-control select" >
                            <option <?= $model->button_eight_open == 1 ? 'selected' : '' ?> value="1">Yes</option>
                            <option <?= $model->button_eight_open == 0 ? 'selected' : '' ?> value="0">No</option>
                        </select>                
                    </div>

                    <div class="col-md-12 form-group">
                        <label for="video">Youtube Embed Link <span class="text-danger">*</span></label>
                        <textarea name="video" id="video" class="form-control" placeholder="Enter Youtube Embed Link" cols="30" rows="2"><?= $model->video ?></textarea>
                    </div>


                    <div class="col-md-4 mx-auto">
                        <button type="submit" class="btn btn-xs btn-block btn-primary pd-x-20">
                            Update &nbsp;&nbsp; <i data-feather="send"></i>
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<?php function pageRequiredScript(){ ?>
    <script>
        $('.select').select2({width:'100%'});
        $('.dropify').dropify();
    </script>
<?php } ?>