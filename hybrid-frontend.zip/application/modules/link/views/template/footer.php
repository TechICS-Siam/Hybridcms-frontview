<footer class="content-footer">
    <div class="col-md-12 text-center">
        <span>Powered and managed by <a style="color:red;" href="https://www.techics.com/" target="_blank">Tech ICS</a></span>
    </div>
</footer>

<?php if(isset($modal)): ?>
<!-- Modal Start -->
<div class="modal fade" data-backdrop="static" id="content_management_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel6" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-<?= $modal ?>" role="document">
        <div class="modal-content tx-14">
            
        </div>
    </div>
</div>
<!-- Modal End -->
<?php endif; ?>