<?php
    $segmentOne = $this->uri->segment(1);
    $segmentTwo = $this->uri->segment(2);
    $segmentThree = $this->uri->segment(3);
?>
<div id="sidebarMenu" class="sidebar sidebar-fixed sidebar-components">
    <div class="sidebar-header">
        <a href="" id="mainMenuOpen">
            <i data-feather="menu"></i>
        </a>

        <h5>
            <img style="width:125px;"  src="<?= $library->logo != null ? base_url(). 'uploads/'. $library->logo : base_url(). 'assets/images/logo-cms.png' ?>" alt="CMS Logo">
        </h5>

        <a href="" id="sidebarMenuClose">
            <i data-feather="x"></i>
        </a>
    </div>

    <div class="sidebar-body">
        <ul class="sidebar-nav">

            <!-- Dashboard -->
            <li class="nav-item">
                <a href="<?= site_url('dashboard') ?>" class="nav-link <?= $segmentOne == 'dashboard' ? 'active' : '' ?>">
                    <i data-feather="layout"></i>
                    Dashboard
                </a>
            </li>

            <!-- Home Page Manager -->
            <li class="nav-item <?= $segmentTwo == 'home-page' ? 'show' : '' ?>">
                <a href="" class="nav-link with-sub <?= $segmentTwo == 'home-page' ? 'active' : '' ?>">
                <i data-feather="airplay"></i> Home Page Manager</a>
                <nav class="nav">
                    <a class="<?= $segmentThree == 'section-one' ? 'active' : '' ?>" href="<?= site_url('admin/home-page/section-one') ?>">Section One</a>
                    <a class="<?= $segmentThree == 'section-two' ? 'active' : '' ?>" href="<?= site_url('admin/home-page/section-two') ?>">Section Two</a>
                    <a class="<?= $segmentThree == 'section-three' ? 'active' : '' ?>" href="<?= site_url('admin/home-page/section-three') ?>">Section Three</a>
                    <a class="<?= $segmentThree == 'section-four' ? 'active' : '' ?>" href="<?= site_url('admin/home-page/section-four') ?>">Section Four</a>
                    <a class="<?= $segmentThree == 'section-five' ? 'active' : '' ?>" href="<?= site_url('admin/home-page/section-five') ?>">Section Five</a>
                    <a class="<?= $segmentThree == 'section-six' ? 'active' : '' ?>" href="<?= site_url('admin/home-page/section-six') ?>">Section Six</a>
                    <a class="<?= $segmentThree == 'section-seven' ? 'active' : '' ?>" href="<?= site_url('admin/home-page/section-seven') ?>">Section Seven</a>
                    <a class="<?= $segmentThree == 'section-eight' ? 'active' : '' ?>" href="<?= site_url('admin/home-page/section-eight') ?>">Section Eight</a>
                    <a class="<?= $segmentThree == 'section-nine' ? 'active' : '' ?>" href="<?= site_url('admin/home-page/section-nine') ?>">Section Nine</a>
                    <a class="<?= $segmentThree == 'section-ten' ? 'active' : '' ?>" href="<?= site_url('admin/home-page/section-ten') ?>">Section Ten</a>
                    <a class="<?= $segmentThree == 'section-eleven' ? 'active' : '' ?>" href="<?= site_url('admin/home-page/section-eleven') ?>">Section Eleven</a>
                </nav>
            </li>

            <!-- User -->
            <li class="nav-item">
                <a href="<?= site_url('admin/users') ?>" class="nav-link <?= $segmentTwo == 'users' || $segmentTwo == 'user' ? 'active' : '' ?> ">
                    <i data-feather="users"></i>
                    Users
                </a>
            </li>

            <!-- Setting -->
            <li class="nav-item <?= $segmentTwo == 'settings' ? 'show' : '' ?>">
                <a href="" class="nav-link with-sub <?= $segmentTwo == 'settings' ? 'active' : '' ?>">
                <i data-feather="settings"></i> Setting</a>
                <nav class="nav">
                    <a class="<?= $segmentThree == 'software-settings' ? 'active' : '' ?>" href="<?= site_url('admin/settings/software-settings') ?>">Software Settings</a>
                    <a class="<?= $segmentThree == 'social-settings' ? 'active' : '' ?>" href="<?= site_url('admin/settings/social-settings') ?>">Social Settings</a>
                    <a class="<?= $segmentThree == 'administrator-login-settings' ? 'active' : '' ?>" href="<?= site_url('admin/settings/administrator-login-settings') ?>">Admin Login Page</a>
                </nav>
            </li>

        </ul>
    </div>
</div>