<div class="content content-fixed">
            <div class="container pd-x-0 pd-lg-x-10 pd-xl-x-0">
                <div class="d-sm-flex align-items-center justify-content-between mg-b-20 mg-lg-b-25 mg-xl-b-30">
                    <div>
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb breadcrumb-style1 mg-b-10">
                                <li class="breadcrumb-item active" aria-current="page">Dashboard</li>
                            </ol>
                        </nav>
                        <h4 class="mg-b-0 tx-spacing--1">Welcome to Dashboard</h4>
                    </div>
                </div>

                <div class="row row-xs">
                    <!-- Number of all cases -->
                    <div class="col-sm-6 mb-2 col-lg-3">
                        <div class="card card-body">
                            <h6 class="tx-uppercase tx-11 tx-spacing-1 tx-color-02 tx-semibold mg-b-8">Number of all cases</h6>
                            <div class="d-flex d-lg-block d-xl-flex align-items-end">
                                <h3 class="tx-normal tx-rubik mg-b-0 mg-r-5 lh-1">100</h3>
                            </div>
                            <div class="chart-three">
                                <div id="flotChart3" class="flot-chart ht-30"></div>
                            </div>
                        </div>
                    </div>

                    <!-- Number of assigned cases -->
                    <div class="col-sm-6 mb-2 col-lg-3">
                        <div class="card card-body">
                            <h6 class="tx-uppercase tx-11 tx-spacing-1 tx-color-02 tx-semibold mg-b-8">Number of assigned cases</h6>
                            <div class="d-flex d-lg-block d-xl-flex align-items-end">
                                <h3 class="tx-normal tx-rubik mg-b-0 mg-r-5 lh-1">15</h3>
                            </div>
                            <div class="chart-three">
                                <div id="flotChart4" class="flot-chart ht-30"></div>
                            </div>  
                        </div>
                    </div>

                    <!-- Number of new cases -->
                    <div class="col-sm-6 mb-2 col-lg-3">
                        <div class="card card-body">
                            <h6 class="tx-uppercase tx-11 tx-spacing-1 tx-color-02 tx-semibold mg-b-8">Number of new cases</h6>
                            <div class="d-flex d-lg-block d-xl-flex align-items-end">
                                <h3 class="tx-normal tx-rubik mg-b-0 mg-r-5 lh-1">87</h3>
                            </div>
                            <div class="chart-three">
                                <div id="flotChart5" class="flot-chart ht-30"></div>
                            </div>
                        </div>
                    </div>

                    <!-- Number of closed cases -->
                    <div class="col-sm-6 mb-2 col-lg-3">
                        <div class="card card-body">
                            <h6 class="tx-uppercase tx-11 tx-spacing-1 tx-color-02 tx-semibold mg-b-8">Number of closed cases</h6>
                            <div class="d-flex d-lg-block d-xl-flex align-items-end">
                                <h3 class="tx-normal tx-rubik mg-b-0 mg-r-5 lh-1">5</h3>
                            </div>
                            <div class="chart-three">
                                <div id="flotChart6" class="flot-chart ht-30"></div>
                            </div>
                        </div>
                    </div>

                    <!-- All Case List -->
                    <div class="col-lg-12 col-xl-6 mg-t-10">
                        <div class="card mg-b-10">
                            <div class="card-header pd-t-20 d-sm-flex align-items-start justify-content-between bd-b-0 pd-b-0">
                                <div>
                                    <h6 class="mg-b-5">All Case List</h6>
                                    <p class="tx-13 tx-color-03 mg-b-0">Your sales and referral earnings over the last 30 days</p>
                                </div>
                            </div>
                            
                            <div class="card-body pd-y-30">
                                <div class="table-responsive" style="height:200px; overflow-y:scroll;">
                                    <table class="table table-dashboard mg-b-0">
                                        <thead>
                                            <tr>
                                            <th>Date</th>
                                            <th class="text-right">Gross Earnings</th>
                                            <th class="text-right">Tax Withheld</th>
                                            <th class="text-right">Net Earnings</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td class="tx-color-03 tx-normal">03/05/2018</td>
                                                <td class="text-right tx-teal">+ $32,580.00</td>
                                                <td class="text-right tx-pink">- $3,023.10</td>
                                                <td class="tx-medium text-right">$28,670.90 <span class="mg-l-5 tx-10 tx-normal tx-success"><i class="icon ion-md-arrow-up"></i> 4.5%</span></td>
                                            </tr>
                                            <tr>
                                                <td class="tx-color-03 tx-normal">03/05/2018</td>
                                                <td class="text-right tx-teal">+ $32,580.00</td>
                                                <td class="text-right tx-pink">- $3,023.10</td>
                                                <td class="tx-medium text-right">$28,670.90 <span class="mg-l-5 tx-10 tx-normal tx-success"><i class="icon ion-md-arrow-up"></i> 4.5%</span></td>
                                            </tr>
                                            <tr>
                                                <td class="tx-color-03 tx-normal">03/05/2018</td>
                                                <td class="text-right tx-teal">+ $32,580.00</td>
                                                <td class="text-right tx-pink">- $3,023.10</td>
                                                <td class="tx-medium text-right">$28,670.90 <span class="mg-l-5 tx-10 tx-normal tx-success"><i class="icon ion-md-arrow-up"></i> 4.5%</span></td>
                                            </tr>
                                            <tr>
                                                <td class="tx-color-03 tx-normal">03/05/2018</td>
                                                <td class="text-right tx-teal">+ $32,580.00</td>
                                                <td class="text-right tx-pink">- $3,023.10</td>
                                                <td class="tx-medium text-right">$28,670.90 <span class="mg-l-5 tx-10 tx-normal tx-success"><i class="icon ion-md-arrow-up"></i> 4.5%</span></td>
                                            </tr>
                                            <tr>
                                                <td class="tx-color-03 tx-normal">03/05/2018</td>
                                                <td class="text-right tx-teal">+ $32,580.00</td>
                                                <td class="text-right tx-pink">- $3,023.10</td>
                                                <td class="tx-medium text-right">$28,670.90 <span class="mg-l-5 tx-10 tx-normal tx-success"><i class="icon ion-md-arrow-up"></i> 4.5%</span></td>
                                            </tr>
                                            <tr>
                                                <td class="tx-color-03 tx-normal">03/05/2018</td>
                                                <td class="text-right tx-teal">+ $32,580.00</td>
                                                <td class="text-right tx-pink">- $3,023.10</td>
                                                <td class="tx-medium text-right">$28,670.90 <span class="mg-l-5 tx-10 tx-normal tx-success"><i class="icon ion-md-arrow-up"></i> 4.5%</span></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- My Assign Case -->
                    <div class="col-lg-12 col-xl-6 mg-t-10">
                        <div class="card mg-b-10">
                            <div class="card-header pd-t-20 d-sm-flex align-items-start justify-content-between bd-b-0 pd-b-0">
                                <div>
                                    <h6 class="mg-b-5">My Assign Case</h6>
                                    <p class="tx-13 tx-color-03 mg-b-0">Your sales and referral earnings over the last 30 days</p>
                                </div>
                            </div>
                            
                            <div class="card-body pd-y-30">
                                <div class="table-responsive" style="height:200px; overflow-y:scroll;">
                                    <table class="table table-dashboard mg-b-0">
                                        <thead>
                                            <tr>
                                            <th>Date</th>
                                            <th class="text-right">Gross Earnings</th>
                                            <th class="text-right">Tax Withheld</th>
                                            <th class="text-right">Net Earnings</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td class="tx-color-03 tx-normal">03/05/2018</td>
                                                <td class="text-right tx-teal">+ $32,580.00</td>
                                                <td class="text-right tx-pink">- $3,023.10</td>
                                                <td class="tx-medium text-right">$28,670.90 <span class="mg-l-5 tx-10 tx-normal tx-success"><i class="icon ion-md-arrow-up"></i> 4.5%</span></td>
                                            </tr>
                                            
                                            <tr>
                                                <td class="tx-color-03 tx-normal">03/05/2018</td>
                                                <td class="text-right tx-teal">+ $32,580.00</td>
                                                <td class="text-right tx-pink">- $3,023.10</td>
                                                <td class="tx-medium text-right">$28,670.90 <span class="mg-l-5 tx-10 tx-normal tx-success"><i class="icon ion-md-arrow-up"></i> 4.5%</span></td>
                                            </tr>
                                            <tr>
                                                <td class="tx-color-03 tx-normal">03/05/2018</td>
                                                <td class="text-right tx-teal">+ $32,580.00</td>
                                                <td class="text-right tx-pink">- $3,023.10</td>
                                                <td class="tx-medium text-right">$28,670.90 <span class="mg-l-5 tx-10 tx-normal tx-success"><i class="icon ion-md-arrow-up"></i> 4.5%</span></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Today's Consultations -->
                    <div class="col-md-6 col-xl-6 mg-t-10 order-md-1 order-xl-0">
                        <div class="card ht-lg-100p">
                            <div class="card-header d-flex align-items-center justify-content-between">
                                <h6 class="mg-b-0">Today’s consultations</h6>
                            </div>
                            <div class="card-body pd-0">
                                <div class="table-responsive">
                                <table class="table table-dashboard mg-b-0">
                                        <thead>
                                            <tr>
                                            <th>Date</th>
                                            <th class="text-right">Gross Earnings</th>
                                            <th class="text-right">Tax Withheld</th>
                                            <th class="text-right">Net Earnings</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td class="tx-color-03 tx-normal">03/05/2018</td>
                                                <td class="text-right tx-teal">+ $32,580.00</td>
                                                <td class="text-right tx-pink">- $3,023.10</td>
                                                <td class="tx-medium text-right">$28,670.90 <span class="mg-l-5 tx-10 tx-normal tx-success"><i class="icon ion-md-arrow-up"></i> 4.5%</span></td>
                                            </tr>
                                            <tr>
                                                <td class="tx-color-03 tx-normal">03/05/2018</td>
                                                <td class="text-right tx-teal">+ $32,580.00</td>
                                                <td class="text-right tx-pink">- $3,023.10</td>
                                                <td class="tx-medium text-right">$28,670.90 <span class="mg-l-5 tx-10 tx-normal tx-success"><i class="icon ion-md-arrow-up"></i> 4.5%</span></td>
                                            </tr>
                                            
                                            <tr>
                                                <td class="tx-color-03 tx-normal">03/05/2018</td>
                                                <td class="text-right tx-teal">+ $32,580.00</td>
                                                <td class="text-right tx-pink">- $3,023.10</td>
                                                <td class="tx-medium text-right">$28,670.90 <span class="mg-l-5 tx-10 tx-normal tx-success"><i class="icon ion-md-arrow-up"></i> 4.5%</span></td>
                                            </tr>
                                            <tr>
                                                <td class="tx-color-03 tx-normal">03/05/2018</td>
                                                <td class="text-right tx-teal">+ $32,580.00</td>
                                                <td class="text-right tx-pink">- $3,023.10</td>
                                                <td class="tx-medium text-right">$28,670.90 <span class="mg-l-5 tx-10 tx-normal tx-success"><i class="icon ion-md-arrow-up"></i> 4.5%</span></td>
                                            </tr>
                                            <tr>
                                                <td class="tx-color-03 tx-normal">03/05/2018</td>
                                                <td class="text-right tx-teal">+ $32,580.00</td>
                                                <td class="text-right tx-pink">- $3,023.10</td>
                                                <td class="tx-medium text-right">$28,670.90 <span class="mg-l-5 tx-10 tx-normal tx-success"><i class="icon ion-md-arrow-up"></i> 4.5%</span></td>
                                            </tr>
                                            <tr>
                                                <td class="tx-color-03 tx-normal">03/05/2018</td>
                                                <td class="text-right tx-teal">+ $32,580.00</td>
                                                <td class="text-right tx-pink">- $3,023.10</td>
                                                <td class="tx-medium text-right">$28,670.90 <span class="mg-l-5 tx-10 tx-normal tx-success"><i class="icon ion-md-arrow-up"></i> 4.5%</span></td>
                                            </tr>
                                            <tr>
                                                <td class="tx-color-03 tx-normal">03/05/2018</td>
                                                <td class="text-right tx-teal">+ $32,580.00</td>
                                                <td class="text-right tx-pink">- $3,023.10</td>
                                                <td class="tx-medium text-right">$28,670.90 <span class="mg-l-5 tx-10 tx-normal tx-success"><i class="icon ion-md-arrow-up"></i> 4.5%</span></td>
                                            </tr>
                                            <tr>
                                                <td class="tx-color-03 tx-normal">03/05/2018</td>
                                                <td class="text-right tx-teal">+ $32,580.00</td>
                                                <td class="text-right tx-pink">- $3,023.10</td>
                                                <td class="tx-medium text-right">$28,670.90 <span class="mg-l-5 tx-10 tx-normal tx-success"><i class="icon ion-md-arrow-up"></i> 4.5%</span></td>
                                            </tr>
                                            <tr>
                                                <td class="tx-color-03 tx-normal">03/05/2018</td>
                                                <td class="text-right tx-teal">+ $32,580.00</td>
                                                <td class="text-right tx-pink">- $3,023.10</td>
                                                <td class="tx-medium text-right">$28,670.90 <span class="mg-l-5 tx-10 tx-normal tx-success"><i class="icon ion-md-arrow-up"></i> 4.5%</span></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Today’s conferences -->
                    <div class="col-lg-12 col-xl-6 mg-t-10">
                        <div class="card mg-b-10">
                            <div class="card-header pd-t-20 d-sm-flex align-items-start justify-content-between bd-b-0 pd-b-0">
                                <div>
                                    <h6 class="mg-b-5">Today’s conferences</h6>
                                    <p class="tx-13 tx-color-03 mg-b-0">Your sales and referral earnings over the last 30 days</p>
                                </div>
                            </div>
                            <div class="card-body pd-y-30">
                                <div class="table-responsive">
                                    <table class="table table-dashboard mg-b-0">
                                        <thead>
                                            <tr>
                                            <th>Date</th>
                                            <th class="text-right">Gross Earnings</th>
                                            <th class="text-right">Tax Withheld</th>
                                            <th class="text-right">Net Earnings</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td class="tx-color-03 tx-normal">03/05/2018</td>
                                                <td class="text-right tx-teal">+ $32,580.00</td>
                                                <td class="text-right tx-pink">- $3,023.10</td>
                                                <td class="tx-medium text-right">$28,670.90 <span class="mg-l-5 tx-10 tx-normal tx-success"><i class="icon ion-md-arrow-up"></i> 4.5%</span></td>
                                            </tr>
                                            <tr>
                                                <td class="tx-color-03 tx-normal">03/05/2018</td>
                                                <td class="text-right tx-teal">+ $32,580.00</td>
                                                <td class="text-right tx-pink">- $3,023.10</td>
                                                <td class="tx-medium text-right">$28,670.90 <span class="mg-l-5 tx-10 tx-normal tx-success"><i class="icon ion-md-arrow-up"></i> 4.5%</span></td>
                                            </tr>
                                            <tr>
                                                <td class="tx-color-03 tx-normal">03/05/2018</td>
                                                <td class="text-right tx-teal">+ $32,580.00</td>
                                                <td class="text-right tx-pink">- $3,023.10</td>
                                                <td class="tx-medium text-right">$28,670.90 <span class="mg-l-5 tx-10 tx-normal tx-success"><i class="icon ion-md-arrow-up"></i> 4.5%</span></td>
                                            </tr>
                                            <tr>
                                                <td class="tx-color-03 tx-normal">03/05/2018</td>
                                                <td class="text-right tx-teal">+ $32,580.00</td>
                                                <td class="text-right tx-pink">- $3,023.10</td>
                                                <td class="tx-medium text-right">$28,670.90 <span class="mg-l-5 tx-10 tx-normal tx-success"><i class="icon ion-md-arrow-up"></i> 4.5%</span></td>
                                            </tr>
                                            <tr>
                                                <td class="tx-color-03 tx-normal">03/05/2018</td>
                                                <td class="text-right tx-teal">+ $32,580.00</td>
                                                <td class="text-right tx-pink">- $3,023.10</td>
                                                <td class="tx-medium text-right">$28,670.90 <span class="mg-l-5 tx-10 tx-normal tx-success"><i class="icon ion-md-arrow-up"></i> 4.5%</span></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        

                        <a href="#">
                            <div class="card card-body ht-lg-100">
                                <div class="media">
                                    <span class="tx-color-04">
                                        <i data-feather="phone-call" class="wd-60 ht-60"></i>
                                    </span>
                                    <div class="media-body mg-l-20">
                                        <h6 class="mg-b-10">My Call Backs</h6>
                                        <p class="tx-color-03 mg-b-0">Open it in a spreadsheet and perform your own calculations.</p>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>

                    <!-- Visa Renewal -->
                    <div class="col-md-6 col-xl-4 mg-t-10">
                        <div class="card ht-100p">
                            <div class="card-header d-flex align-items-center justify-content-between">
                                <h6 class="mg-b-0">Visa Renewal</h6>
                            </div>
                            <ul class="list-group list-group-flush tx-13">
                                <li class="list-group-item d-flex pd-sm-x-20">
                                    <div class="avatar d-none d-sm-block">
                                        <span class="avatar-initial rounded-circle bg-teal">
                                            <i class="icon ion-md-checkmark"></i>
                                        </span>
                                    </div>
                                    <div class="pd-sm-l-10">
                                        <p class="tx-medium mg-b-0">Payment from #10322</p>
                                        <small class="tx-12 tx-color-03 mg-b-0">Mar 21, 2019, 3:30pm</small>
                                    </div>
                                    <div class="mg-l-auto text-right">
                                        <p class="tx-medium mg-b-0">+ $250.00</p>
                                        <small class="tx-12 tx-success mg-b-0">Completed</small>
                                    </div>
                                </li>
                                <li class="list-group-item d-flex pd-sm-x-20">
                                    <div class="avatar d-none d-sm-block">
                                        <span class="avatar-initial rounded-circle bg-teal">
                                            <i class="icon ion-md-checkmark"></i>
                                        </span>
                                    </div>
                                    <div class="pd-sm-l-10">
                                        <p class="tx-medium mg-b-0">Payment from #10322</p>
                                        <small class="tx-12 tx-color-03 mg-b-0">Mar 21, 2019, 3:30pm</small>
                                    </div>
                                    <div class="mg-l-auto text-right">
                                        <p class="tx-medium mg-b-0">+ $250.00</p>
                                        <small class="tx-12 tx-success mg-b-0">Completed</small>
                                    </div>
                                </li>
                                <li class="list-group-item d-flex pd-sm-x-20">
                                    <div class="avatar d-none d-sm-block">
                                        <span class="avatar-initial rounded-circle bg-teal">
                                            <i class="icon ion-md-checkmark"></i>
                                        </span>
                                    </div>
                                    <div class="pd-sm-l-10">
                                        <p class="tx-medium mg-b-0">Payment from #10322</p>
                                        <small class="tx-12 tx-color-03 mg-b-0">Mar 21, 2019, 3:30pm</small>
                                    </div>
                                    <div class="mg-l-auto text-right">
                                        <p class="tx-medium mg-b-0">+ $250.00</p>
                                        <small class="tx-12 tx-success mg-b-0">Completed</small>
                                    </div>
                                </li>
                                <li class="list-group-item d-flex pd-sm-x-20">
                                    <div class="avatar d-none d-sm-block">
                                        <span class="avatar-initial rounded-circle bg-teal">
                                            <i class="icon ion-md-checkmark"></i>
                                        </span>
                                    </div>
                                    <div class="pd-sm-l-10">
                                        <p class="tx-medium mg-b-0">Payment from #10322</p>
                                        <small class="tx-12 tx-color-03 mg-b-0">Mar 21, 2019, 3:30pm</small>
                                    </div>
                                    <div class="mg-l-auto text-right">
                                        <p class="tx-medium mg-b-0">+ $250.00</p>
                                        <small class="tx-12 tx-success mg-b-0">Completed</small>
                                    </div>
                                </li>
                                <li class="list-group-item d-flex pd-sm-x-20">
                                    <div class="avatar d-none d-sm-block">
                                        <span class="avatar-initial rounded-circle bg-teal">
                                            <i class="icon ion-md-checkmark"></i>
                                        </span>
                                    </div>
                                    <div class="pd-sm-l-10">
                                        <p class="tx-medium mg-b-0">Payment from #10322</p>
                                        <small class="tx-12 tx-color-03 mg-b-0">Mar 21, 2019, 3:30pm</small>
                                    </div>
                                    <div class="mg-l-auto text-right">
                                        <p class="tx-medium mg-b-0">+ $250.00</p>
                                        <small class="tx-12 tx-success mg-b-0">Completed</small>
                                    </div>
                                </li>
                            </ul>
                            <div class="card-footer text-center tx-13">
                                <a href="" class="link-03">View All Visa Renewal <i class="icon ion-md-arrow-down mg-l-5"></i></a>
                            </div>
                        </div>
                    </div>

                    <!-- Document Requests  -->
                    <div class="col-md-6 col-xl-4 mg-t-10">
                        <div class="card ht-100p">
                            <div class="card-header d-flex align-items-center justify-content-between">
                                <h6 class="mg-b-0">Document Requests </h6>
                            </div>
                            <ul class="list-group list-group-flush tx-13">
                                <li class="list-group-item d-flex pd-sm-x-20">
                                    <div class="avatar"><span class="avatar-initial rounded-circle bg-gray-600">s</span></div>
                                    <div class="pd-l-10">
                                        <p class="tx-medium mg-b-0">Socrates Itumay</p>
                                        <small class="tx-12 tx-color-03 mg-b-0">Customer ID#00222</small>
                                    </div>
                           
                            </li>
                            <li class="list-group-item d-flex pd-x-20">
                            <div class="avatar"><img src="https://via.placeholder.com/500" class="rounded-circle" alt=""></div>
                            <div class="pd-l-10">
                                <p class="tx-medium mg-b-0">Reynante Labares</p>
                                <small class="tx-12 tx-color-03 mg-b-0">Customer ID#00221</small>
                            </div>
                           
                            </li>
                            <li class="list-group-item d-flex pd-x-20">
                            <div class="avatar"><img src="https://via.placeholder.com/500" class="rounded-circle" alt=""></div>
                            <div class="pd-l-10">
                                <p class="tx-medium mg-b-0">Marianne Audrey</p>
                                <small class="tx-12 tx-color-03 mg-b-0">Customer ID#00220</small>
                            </div>
                          
                            </li>
                            <li class="list-group-item d-flex pd-x-20">
                            <div class="avatar"><span class="avatar-initial rounded-circle bg-indigo op-5">o</span></div>
                            <div class="pd-l-10">
                                <p class="tx-medium mg-b-0">Owen Bongcaras</p>
                                <small class="tx-12 tx-color-03 mg-b-0">Customer ID#00219</small>
                            </div>
                          
                            </li>
                            <li class="list-group-item d-flex pd-x-20">
                            <div class="avatar"><span class="avatar-initial rounded-circle bg-primary op-5">k</span></div>
                            <div class="pd-l-10">
                                <p class="tx-medium mg-b-0">Kirby Avendula</p>
                                <small class="tx-12 tx-color-03 mg-b-0">Customer ID#00218</small>
                            </div>
                          
                            </li>
                        </ul>
                        <div class="card-footer text-center tx-13">
                            <a href="" class="link-03">View More Document Requests  <i class="icon ion-md-arrow-down mg-l-5"></i></a>
                        </div><!-- card-footer -->
                        </div><!-- card -->
                    </div>

                    <!-- Pending Case Note -->
                    <div class="col-md-6 col-xl-4 mg-t-10">
                        <div class="card ht-100p">
                            <div class="card-header d-flex align-items-center justify-content-between">
                                <h6 class="mg-b-0">Pending Case Note</h6>
                            </div>
                            <ul class="list-group list-group-flush tx-13">
                                <li class="list-group-item d-flex pd-sm-x-20">
                                    <div class="avatar d-none d-sm-block">
                                        <span class="avatar-initial rounded-circle bg-teal">
                                            <i class="icon ion-md-checkmark"></i>
                                        </span>
                                    </div>
                                    <div class="pd-sm-l-10">
                                        <p class="tx-medium mg-b-0">Payment from #10322</p>
                                        <small class="tx-12 tx-color-03 mg-b-0">Mar 21, 2019, 3:30pm</small>
                                    </div>
                                    <div class="mg-l-auto text-right">
                                        <p class="tx-medium mg-b-0">+ $250.00</p>
                                        <small class="tx-12 tx-success mg-b-0">Completed</small>
                                    </div>
                                </li>
                                <li class="list-group-item d-flex pd-sm-x-20">
                                    <div class="avatar d-none d-sm-block">
                                        <span class="avatar-initial rounded-circle bg-teal">
                                            <i class="icon ion-md-checkmark"></i>
                                        </span>
                                    </div>
                                    <div class="pd-sm-l-10">
                                        <p class="tx-medium mg-b-0">Payment from #10322</p>
                                        <small class="tx-12 tx-color-03 mg-b-0">Mar 21, 2019, 3:30pm</small>
                                    </div>
                                    <div class="mg-l-auto text-right">
                                        <p class="tx-medium mg-b-0">+ $250.00</p>
                                        <small class="tx-12 tx-success mg-b-0">Completed</small>
                                    </div>
                                </li>
                                <li class="list-group-item d-flex pd-sm-x-20">
                                    <div class="avatar d-none d-sm-block">
                                        <span class="avatar-initial rounded-circle bg-teal">
                                            <i class="icon ion-md-checkmark"></i>
                                        </span>
                                    </div>
                                    <div class="pd-sm-l-10">
                                        <p class="tx-medium mg-b-0">Payment from #10322</p>
                                        <small class="tx-12 tx-color-03 mg-b-0">Mar 21, 2019, 3:30pm</small>
                                    </div>
                                    <div class="mg-l-auto text-right">
                                        <p class="tx-medium mg-b-0">+ $250.00</p>
                                        <small class="tx-12 tx-success mg-b-0">Completed</small>
                                    </div>
                                </li>
                                <li class="list-group-item d-flex pd-sm-x-20">
                                    <div class="avatar d-none d-sm-block">
                                        <span class="avatar-initial rounded-circle bg-teal">
                                            <i class="icon ion-md-checkmark"></i>
                                        </span>
                                    </div>
                                    <div class="pd-sm-l-10">
                                        <p class="tx-medium mg-b-0">Payment from #10322</p>
                                        <small class="tx-12 tx-color-03 mg-b-0">Mar 21, 2019, 3:30pm</small>
                                    </div>
                                    <div class="mg-l-auto text-right">
                                        <p class="tx-medium mg-b-0">+ $250.00</p>
                                        <small class="tx-12 tx-success mg-b-0">Completed</small>
                                    </div>
                                </li>
                                <li class="list-group-item d-flex pd-sm-x-20">
                                    <div class="avatar d-none d-sm-block">
                                        <span class="avatar-initial rounded-circle bg-teal">
                                            <i class="icon ion-md-checkmark"></i>
                                        </span>
                                    </div>
                                    <div class="pd-sm-l-10">
                                        <p class="tx-medium mg-b-0">Payment from #10322</p>
                                        <small class="tx-12 tx-color-03 mg-b-0">Mar 21, 2019, 3:30pm</small>
                                    </div>
                                    <div class="mg-l-auto text-right">
                                        <p class="tx-medium mg-b-0">+ $250.00</p>
                                        <small class="tx-12 tx-success mg-b-0">Completed</small>
                                    </div>
                                </li>
                            </ul>
                            <div class="card-footer text-center tx-13">
                                <a href="" class="link-03">View All Pending Case Note <i class="icon ion-md-arrow-down mg-l-5"></i></a>
                            </div>
                        </div>
                    </div>

                    <!-- Appeal Lodged -->
                    <div class="col-md-6 col-xl-6 mg-t-10">
                        <div class="card ht-100p">
                            <div class="card-header d-flex align-items-center justify-content-between">
                                <h6 class="mg-b-0">Appeal Lodged</h6>
                            </div>
                            <ul class="list-group list-group-flush tx-13">
                                <li class="list-group-item d-flex pd-sm-x-20">
                                    <div class="avatar d-none d-sm-block">
                                        <span class="avatar-initial rounded-circle bg-teal">
                                            <i class="icon ion-md-checkmark"></i>
                                        </span>
                                    </div>
                                    <div class="pd-sm-l-10">
                                        <p class="tx-medium mg-b-0">Payment from #10322</p>
                                        <small class="tx-12 tx-color-03 mg-b-0">Mar 21, 2019, 3:30pm</small>
                                    </div>
                                    <div class="mg-l-auto text-right">
                                        <p class="tx-medium mg-b-0">+ $250.00</p>
                                        <small class="tx-12 tx-success mg-b-0">Completed</small>
                                    </div>
                                </li>
                                <li class="list-group-item d-flex pd-sm-x-20">
                                    <div class="avatar d-none d-sm-block">
                                        <span class="avatar-initial rounded-circle bg-teal">
                                            <i class="icon ion-md-checkmark"></i>
                                        </span>
                                    </div>
                                    <div class="pd-sm-l-10">
                                        <p class="tx-medium mg-b-0">Payment from #10322</p>
                                        <small class="tx-12 tx-color-03 mg-b-0">Mar 21, 2019, 3:30pm</small>
                                    </div>
                                    <div class="mg-l-auto text-right">
                                        <p class="tx-medium mg-b-0">+ $250.00</p>
                                        <small class="tx-12 tx-success mg-b-0">Completed</small>
                                    </div>
                                </li>
                                <li class="list-group-item d-flex pd-sm-x-20">
                                    <div class="avatar d-none d-sm-block">
                                        <span class="avatar-initial rounded-circle bg-teal">
                                            <i class="icon ion-md-checkmark"></i>
                                        </span>
                                    </div>
                                    <div class="pd-sm-l-10">
                                        <p class="tx-medium mg-b-0">Payment from #10322</p>
                                        <small class="tx-12 tx-color-03 mg-b-0">Mar 21, 2019, 3:30pm</small>
                                    </div>
                                    <div class="mg-l-auto text-right">
                                        <p class="tx-medium mg-b-0">+ $250.00</p>
                                        <small class="tx-12 tx-success mg-b-0">Completed</small>
                                    </div>
                                </li>
                                <li class="list-group-item d-flex pd-sm-x-20">
                                    <div class="avatar d-none d-sm-block">
                                        <span class="avatar-initial rounded-circle bg-teal">
                                            <i class="icon ion-md-checkmark"></i>
                                        </span>
                                    </div>
                                    <div class="pd-sm-l-10">
                                        <p class="tx-medium mg-b-0">Payment from #10322</p>
                                        <small class="tx-12 tx-color-03 mg-b-0">Mar 21, 2019, 3:30pm</small>
                                    </div>
                                    <div class="mg-l-auto text-right">
                                        <p class="tx-medium mg-b-0">+ $250.00</p>
                                        <small class="tx-12 tx-success mg-b-0">Completed</small>
                                    </div>
                                </li>
                                <li class="list-group-item d-flex pd-sm-x-20">
                                    <div class="avatar d-none d-sm-block">
                                        <span class="avatar-initial rounded-circle bg-teal">
                                            <i class="icon ion-md-checkmark"></i>
                                        </span>
                                    </div>
                                    <div class="pd-sm-l-10">
                                        <p class="tx-medium mg-b-0">Payment from #10322</p>
                                        <small class="tx-12 tx-color-03 mg-b-0">Mar 21, 2019, 3:30pm</small>
                                    </div>
                                    <div class="mg-l-auto text-right">
                                        <p class="tx-medium mg-b-0">+ $250.00</p>
                                        <small class="tx-12 tx-success mg-b-0">Completed</small>
                                    </div>
                                </li>
                            </ul>
                            <div class="card-footer text-center tx-13">
                                <a href="" class="link-03">View All Appeal Lodged <i class="icon ion-md-arrow-down mg-l-5"></i></a>
                            </div>
                        </div>
                    </div>

                    <!-- Appeal Hearing Dates  -->
                    <div class="col-md-6 col-xl-6 mg-t-10">
                        <div class="card ht-100p">
                            <div class="card-header d-flex align-items-center justify-content-between">
                                <h6 class="mg-b-0">Appeal Hearing Dates </h6>
                            </div>
                            <ul class="list-group list-group-flush tx-13">
                                <li class="list-group-item d-flex pd-sm-x-20">
                                    <div class="avatar"><span class="avatar-initial rounded-circle bg-gray-600">s</span></div>
                                    <div class="pd-l-10">
                                        <p class="tx-medium mg-b-0">Socrates Itumay</p>
                                        <small class="tx-12 tx-color-03 mg-b-0">Customer ID#00222</small>
                                    </div>
                            
                            </li>
                            <li class="list-group-item d-flex pd-x-20">
                            <div class="avatar"><img src="https://via.placeholder.com/500" class="rounded-circle" alt=""></div>
                            <div class="pd-l-10">
                                <p class="tx-medium mg-b-0">Reynante Labares</p>
                                <small class="tx-12 tx-color-03 mg-b-0">Customer ID#00221</small>
                            </div>
                            
                            </li>
                            <li class="list-group-item d-flex pd-x-20">
                            <div class="avatar"><img src="https://via.placeholder.com/500" class="rounded-circle" alt=""></div>
                            <div class="pd-l-10">
                                <p class="tx-medium mg-b-0">Marianne Audrey</p>
                                <small class="tx-12 tx-color-03 mg-b-0">Customer ID#00220</small>
                            </div>
                           
                            </li>
                            <li class="list-group-item d-flex pd-x-20">
                            <div class="avatar"><span class="avatar-initial rounded-circle bg-indigo op-5">o</span></div>
                            <div class="pd-l-10">
                                <p class="tx-medium mg-b-0">Owen Bongcaras</p>
                                <small class="tx-12 tx-color-03 mg-b-0">Customer ID#00219</small>
                            </div>
                            
                            </li>
                            <li class="list-group-item d-flex pd-x-20">
                            <div class="avatar"><span class="avatar-initial rounded-circle bg-primary op-5">k</span></div>
                            <div class="pd-l-10">
                                <p class="tx-medium mg-b-0">Kirby Avendula</p>
                                <small class="tx-12 tx-color-03 mg-b-0">Customer ID#00218</small>
                            </div>
                           
                            </li>
                        </ul>
                        <div class="card-footer text-center tx-13">
                            <a href="" class="link-03">View More Appeal Hearing Dates  <i class="icon ion-md-arrow-down mg-l-5"></i></a>
                        </div><!-- card-footer -->
                        </div><!-- card -->
                    </div>
          
                </div>
            </div>
        </div>