<!--Breadcrumb-->
<div class="breadcrumb-line breadcrumb-line-light bg-white breadcrumb-line-component header-elements-md-inline mb-4">
    <div class="d-flex">
        <div class="breadcrumb">
            <a href="#" class="breadcrumb-item"><i class="icon-dots"></i> Website Settings</a>
        </div>
        <a href="#" class="header-elements-toggle text-default d-md-none"><i class="icon-more"></i></a>
    </div>

    <div class="header-elements d-none">
        <div class="breadcrumb">
            <a href="<?= site_url('dashboard') ?>" class="breadcrumb-item"><i class="icon-home2 mr-2"></i> Home</a>
            <span class="breadcrumb-item active">Update Website Settings</span>
        </div>
    </div>
</div>

<div class="content">
    <div class="row">
        <div class="col-md-2"></div>
        <div class="col-md-8">
            <!-- Grey background, left button spacing -->
            <form action="<?php echo site_url('software_settings/update') ?>/<?php echo $get_settigns->id; ?>" method="post" enctype="multipart/form-data" >

                <div class="card">
                    <?php

                    $success= $this->session->flashdata('success');
                    $warning= $this->session->flashdata('warning');

                    if (isset($success)) {

                        ?>
                        <div class="alert alert-success alert-styled-left alert-arrow-left alert-dismissible">
                            <span class="font-weight-semibold">Well done!</span> <?php echo $success; ?>
                        </div>
                    <?php }elseif(isset($warning)){ ?>
                        <div class="alert alert-warning alert-styled-left alert-dismissible">
                            <span class="font-weight-semibold">Warning!</span> <?php echo $warning; ?>
                        </div>
                    <?php  } ?>

                    <div class="card-header bg-white header-elements-inline">
                        <h6 class="card-title">Update Website Settings</h6>
                        <div class="header-elements">
                            <div class="list-icons">
                                <a class="list-icons-item" data-action="collapse"></a>
                                <a class="list-icons-item" data-action="reload"></a>
                                <a class="list-icons-item" data-action="remove"></a>
                            </div>
                        </div>
                    </div>

                    <div class="card-body">
                        <div class="row">

                            <div class="col-md-12">
                                <div class="form-group">
                                    <label>Company Name:</label>
                                    <input type="text" name="company_name" class="form-control" value="<?php echo $get_settigns->company_name; ?>" >
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Phone Number:</label>
                                    <input type="text" name="mobile" class="form-control" value="<?php echo $get_settigns->mobile; ?>">
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Phone:</label>
                                    <input type="text" name="call_number" class="form-control" value="<?php echo $get_settigns->call_number; ?>">
                                </div>
                            </div>

                            <div class="col-md-12">
                                <div class="form-group">
                                    <label>Email Address:</label>
                                    <input type="text" name="email" class="form-control" value="<?php echo $get_settigns->email; ?>">
                                </div>
                            </div>

                            <div class="col-md-12">
                                <div class="form-group">
                                    <label>Footer Content:</label>
                                    <textarea name="footer_content" id="footer_content" class="form-control" cols="30" rows="5"><?= $get_settigns->footer_content ?></textarea>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group image_update">
                                    <label>Company Logo:</label>
                                    <input type="file" name="logo" class="form-control-uniform-custom">
                                    <img class="card-img img-fluid" src="<?php echo base_url(); ?>uploads/software_settings/<?php echo $get_settigns->logo; ?>" alt="Logo">
                                </div>
                            </div>

<!--                            <div class="col-md-4">
                                <div class="form-group image_update">
                                    <label>Invoice Logo:</label>
                                    <input type="file" name="invoice_logo" class="form-control-uniform-custom">
                                    <img class="card-img img-fluid" src="<?php echo base_url(); ?>uploads/software_settings/<?php echo $get_settigns->invoice_logo; ?>" alt="Logo">
                                </div>
                            </div>-->
                            <div class="col-md-6">
                                <div class="form-group image_update">
                                    <label>Favicon Icon:</label>
                                    <input type="file" name="favicon" class="form-control-uniform-custom">
                                    <img class="card-img img-fluid" src="<?php echo base_url(); ?>uploads/software_settings/<?php echo $get_settigns->favicon; ?>" alt="Logo">
                                </div>
                            </div>

                            <div class="col-md-12">
                                <div class="form-group">
                                    <label>Last Updated Date:</label>
                                    <input type="text" name="date_time" class="form-control" value="<?php echo date("F j, Y, g:i A",strtotime($get_settigns->date_time)); ?>" readonly>
                                </div>
                            </div>

                        </div>

                    </div>

                    <div class="card-footer">
                        <div class="col-md-4 mx-auto">
                            <button id="noty_warning" type="submit" class="btn btn-block bg-blue ml-3 bg-teal-400">Update <i class="icon-paperplane ml-2"></i></button>
                        </div>
                    </div>
                </div>

            </form>
        </div>

    </div>
</div>

