<?php

class Software_settings_model extends CI_Model
{
    public function get_settigns()
    {
        $this->db->select('*');
        $this->db->from('techics_software_settings');
        $query = $this->db->get();
        $res = $query->num_rows();
        if ($res === 1) {
            $result = $query->row();
            return $result;
        } else {
            return FALSE;
        }
    }

    public function update($data,$id) {
        $this->db->where('id', $id);
        $this->db->update('techics_software_settings', $data);
    }

}