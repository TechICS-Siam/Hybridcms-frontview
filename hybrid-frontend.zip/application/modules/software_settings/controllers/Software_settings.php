<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Software_settings extends MX_Controller
{

    function __construct()
    {
        parent::__construct();
        $data = array();
        $this->load->model('Software_settings_model');
        $this->load->module('templates');
        $this->load->helper('file_uploader');
    }

    public function add()
    {
        $data['get_settigns'] = $this->Software_settings_model->get_settigns();

        $data['view_file'] = "add";
        $this->templates->admin($data);
    }

    public function update()
    {
        $id = $this->uri->segment(3);

        $query = $this->db->from('techics_software_settings')->where('id', 1)->get()->row();

        $data = array
        (
            'company_name'  => $this->input->post('company_name'),
            'email'         => $this->input->post('email'),
            'mobile'        => $this->input->post('mobile'),
            'call_number'   => $this->input->post('call_number'),
            'footer_content'=> $this->input->post('footer_content'),
            'date_time'     => date('Y-m-d H:i:s')
        );

        if(isset($_FILES['logo']['name']) && $_FILES['logo']['name'] != '') {
            $title = 'logo';
            $logo = uploadFileWithCustomName('uploads/software_settings','logo', $title ,'*');
            if($logo && $query->logo != NULL) {
                $link = './uploads/software_settings/' . $query->logo;
                unlink($link);
            }

            $data['logo'] = $logo;
        }

        if(isset($_FILES['favicon']['name']) && $_FILES['favicon']['name'] != '') {
            $title = 'favicon';
            $favicon = uploadFileWithCustomName('uploads/software_settings','favicon', $title ,'*');
            if($favicon && $query->favcion != NULL) {
                $link = './uploads/software_settings/' . $query->favicon;
                unlink($link);
            }

            $data['favicon'] = $favicon;
        }

        $this->Software_settings_model->update($data, $id);
        $sdata['success'] = "Website Settings Updated Successfully";
        $this->session->set_flashdata($sdata);
        redirect('software_settings/add');
    }
}
